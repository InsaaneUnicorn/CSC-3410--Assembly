BITS 32

global _start

section .text

_start:
    ; this is the code to print "The Adding Program"
    mov eax, 4 ; The write system call ID is 4
    mov ebx, 1 ; for std output the file descripter is 1
    mov ecx, msg
    mov edx, msg_len
    int 0x80

    ; This is the code to write the user input msg part 1
    mov eax, 4
    mov ebx, 1
    mov ecx, msg_nums ; pointer to string you want to print/output
    mov edx, msg_nums_len ; len of string you want to output
    int 0x80

    ; This is the code to read the user input part 1
    mov eax, 3 ; the read system call id is 3
    mov ebx, 0 ; the file descripter for std input is 0
    mov ecx, num_1 ; the buffer/pointer to buffer/variable
    mov edx, 2 ; size of buffer/maximum number of chars to read. it's 2 bc of the enter new line
    int 0x80

    ; This is the code to write the user input msg part 2
    mov eax, 4
    mov ebx, 1 
    mov ecx, msg_nums
    mov edx, msg_nums_len
    int 0x80



    ; This is the code to read the user input msg part 2
    mov eax, 3
    mov ebx, 0
    mov ecx, num_2
    mov edx, 2
    int 0x80

    ; THE MATH! now we need to move numbers/chars from memory into the registers. The moves before are just moving the system call to the buffers in memory
    ; since we only need 8 bits i'm gonna use the smaller 8 bit registers e.g. al bl cl dl
    mov al, [num_1]
    mov bl, [num_2]
    sub al, 48 ; or you can use single quote 0, '0'
    sub bl, 48
    add al, bl
    add al, 48
    mov [answer], al

    ; code to write the answer back out to the user
    mov eax, 4
    mov ebx, 1
    mov ecx, msg_answer
    mov edx, msg_answer_len
    int 0x80

    mov eax, 4
    mov ebx, 1
    mov ecx, answer ; looking specifically for a pointer to memory so you don't need []
    mov edx, 2
    int 0x80

    ; printing a new line
    mov eax, 4
    mov ebx, 1
    mov ecx, newline
    mov edx, 1
    int 0x80

    mov eax, 1 ; system call id for exit
    mov ebx, 0 ; indicates no error
    int 0x80

section .data
    msg DB "The Adding Program", 0xa ; 0xa is the Hexidecimal code for the new line character
    msg_len equ $ - msg
    msg_nums DB "Please enter a single digit number: "
    msg_nums_len equ $ - msg_nums
    msg_answer DB "The answer is: "
    msg_answer_len equ $ - msg_answer
    newline DB 0xa

section .bss

    num_1 resb 2
    num_2 resb 2
    answer resb 2