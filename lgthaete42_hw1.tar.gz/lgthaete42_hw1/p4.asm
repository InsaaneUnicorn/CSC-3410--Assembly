BITS 32

global _start

section .text

_start:
    ; this is the code to print "The Adding Program"
    mov eax, 4 ; The write system call ID is 4
    mov ebx, 1 ; for std output the file descripter is 1
    mov ecx, msg
    mov edx, msg_len
    int 0x80

    ; This is the code to write the user input msg 
    mov eax, 4
    mov ebx, 1
    mov ecx, msg_nums ; pointer to string you want to print/output
    mov edx, msg_nums_len ; len of string you want to output
    int 0x80

    ; This is the code to read the user input 
    mov eax, 3 ; the read system call id is 3
    mov ebx, 0 ; the file descripter for std input is 0
    mov ecx, two_char_string ; the buffer/pointer to buffer/variable
    mov edx, 3 ; size of buffer/maximum number of chars to read. it's 3 bc of the enter new line
    int 0x80

    ; The logic for the swapping
    mov al, [two_char_string + 0]
    mov bl, [two_char_string + 1]
    mov [two_char_string + 1], al
    mov [two_char_string + 0], bl


    ; code to write the answer back out to the user
    mov eax, 4
    mov ebx, 1
    mov ecx, msg_answer
    mov edx, msg_answer_len
    int 0x80

    mov eax, 4
    mov ebx, 1
    mov ecx, two_char_string ; looking specifically for a pointer to memory so you don't need []
    mov edx, 2
    int 0x80

    ; printing a new line
    mov eax, 4
    mov ebx, 1
    mov ecx, newline
    mov edx, 1
    int 0x80

    mov eax, 1 ; system call id for exit
    mov ebx, 0 ; indicates no error
    int 0x80

section .data
    msg DB "The Swapping Program", 0xa ; 0xa is the Hexidecimal code for the new line character
    msg_len equ $ - msg
    msg_nums DB "Please enter a 2 character string: "
    msg_nums_len equ $ - msg_nums
    msg_answer DB "The answer is: "
    msg_answer_len equ $ - msg_answer
    newline DB 0xa

section .bss

    two_char_string resb 3
